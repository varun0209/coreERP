import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-series',
  templateUrl: './no-series.component.html',
  styleUrls: ['./no-series.component.scss']
})
export class NoSeriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
